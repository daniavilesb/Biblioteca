/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.util.Date;

/**
 *
 * @author Daniel
 */
public class FutureRequest {
    
    public Integer FutureRequestID;
    public Date FutureRequestDate;
    public Boolean Active;
    
     
public void FutureRequest (){
    
       

    }
            
    
    
    
}
