/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

/**
 *
 * @author Daniel
 */
public class Checkout {

    public Integer fine;
    public Date deliverydate;

    public int checkout_request(int bookid, int cardnumber, int multimediaid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int multa = 0;
        String sbookid, smultimediaid;

        if (bookid == 0) {
            sbookid = null;
        } else {
            sbookid = String.valueOf(bookid);
        }
        if (multimediaid == 0) {
            smultimediaid = null;
        } else {
            smultimediaid = String.valueOf(multimediaid);
        }

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("sp_CheckOutFine ?,?,?");
            ps.setInt(1, bookid);
            ps.setInt(2, cardnumber);
            ps.setInt(3, multimediaid);

            rs = ps.executeQuery();
            while (rs.next()) {
                multa = rs.getInt(1);
            }
            rs.close();
            return multa;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {

                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {

                }
            }
        }
        
        
        

    }
    
    
    public void checkout_norequest(int bookid, int cardnumber, int multimediaid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int multa = 0;
        String sbookid, smultimediaid;

        if (bookid == 0) {
            sbookid = null;
        } else {
            sbookid = String.valueOf(bookid);
        }
        if (multimediaid == 0) {
            smultimediaid = null;
        } else {
            smultimediaid = String.valueOf(multimediaid);
        }

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("sp_CheckOut ?,?,?");
            ps.setInt(1, bookid);
            ps.setInt(2, cardnumber);
            ps.setInt(3, multimediaid);

            rs = ps.executeQuery();
            
            rs.close();
            
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {

                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {

                }
            }
        }
    }
}
