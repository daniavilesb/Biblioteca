/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Daniel
 */
public class Book {

    public String Editorial;
    public Integer BookID;
    public Boolean Status;
    public Boolean Able;
    public String Author;

    public int BookAvailability(int itemid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int bookid = 0;
        

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec spU_bookavailability ?");
            //ps.setString(1, filter);   
            
            ps.setInt(1, itemid);
            

            System.out.println();

            rs = ps.executeQuery();
            while (rs.next()) {
                bookid = rs.getInt(1);
            }     
            rs.close();
            return bookid;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }

    }
    
     public int bestseller(int bookid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int best = 0;
        

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec spU_is_bestseller ?");
            //ps.setString(1, filter);   
            
            ps.setInt(1, bookid);
            

            System.out.println();

            rs = ps.executeQuery();
            while (rs.next()) {
                bookid = rs.getInt(1);
            }     
            rs.close();
            return bookid;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }

    }

   

}
