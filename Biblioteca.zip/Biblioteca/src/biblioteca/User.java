/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author Daniel
 */


public class User {

    public Integer CarNumber;
    public String Name;
    public String Birthdate;
    public Integer Phone;
    public String Address;
    public Boolean Active;
    public Integer Identificacion;


    
    public int consult_age(int cardnumber) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int edad = 0;

        int iteration = 0, sum = 0, row = 1;

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec sp_age ?");
            ps.setInt(1, cardnumber);


            rs = ps.executeQuery();
           while (rs.next()) {
                edad = rs.getInt(1);
            }
            rs.close();
            return edad;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {

                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {

                }
            }
        }
    }
    
      public String[][] consult_users(String filter) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;

        int iteration = 0, sum = 0, row = 1;

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec spU_listusers ?");
            //ps.setString(1, filter);               
            ps.setString(1, filter);            

            System.out.println();

            rs = ps.executeQuery();
            while (rs.next()) {
                iteration = iteration + 1;
            }
            String books[][] = new String[iteration][6];
            rs = ps.executeQuery();
            while (rs.next()) {

                //System.out.println(rs.getString(1)+ " , "+ rs.getString(2));
                books[sum][0] = rs.getString(1);
                books[sum][1] = rs.getString(2);
                books[sum][2] = rs.getString(3);
                books[sum][3] = rs.getString(4);                
                books[sum][5] = String.valueOf(rs.getDate(5));
               

                //books[sum][5] = String.valueOf(rs.getDate(6));
                sum = sum + 1;
            }
            System.out.println(books[0]);
            rs.close();
            return books;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }

    }
    
    
    
    
    }
