/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Daniel
 */
public class Request {

    public Integer RequestID;
    public String nowdate;
    public String desireddate;

    public void request(int cardnumber, int kind, int age, int itemid, int itembyuser) throws ParseException, IOException {

        Calendar RequestDate = Calendar.getInstance();
        Calendar DesiredDeliveryDate = Calendar.getInstance();
        Book book = new Book();
        Multimedia multi = new Multimedia();
        int resourceid = 0, bestseller = 0;

        if (kind == 1) {
            resourceid = book.BookAvailability(itemid);
            bestseller = book.bestseller(resourceid);
        }
        if (kind == 2) {
            resourceid = multi.multimediaavailability(itemid);
        }

        int year = RequestDate.get(Calendar.YEAR);
        int month = RequestDate.get(Calendar.MONTH);
        int day = RequestDate.get(Calendar.DAY_OF_MONTH);
        int hour = RequestDate.get(Calendar.HOUR);
        int minute = RequestDate.get(Calendar.MINUTE);
        int second = RequestDate.get(Calendar.SECOND);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        nowdate = year + "-" + (month + 1) + "-" + day + " " + hour + ":" + minute + ":" + second;

        if (kind == 1 && bestseller == 1) {

            Date d = sdf.parse(nowdate);
            DesiredDeliveryDate = RequestDate;

            nowdate = format.format(d);

            DesiredDeliveryDate.add(Calendar.DAY_OF_MONTH, 7);

            int year1 = DesiredDeliveryDate.get(Calendar.YEAR);
            int month1 = DesiredDeliveryDate.get(Calendar.MONTH);
            int day1 = DesiredDeliveryDate.get(Calendar.DAY_OF_MONTH);
            int hour1 = DesiredDeliveryDate.get(Calendar.HOUR);
            int minute1 = DesiredDeliveryDate.get(Calendar.MINUTE);
            int second1 = DesiredDeliveryDate.get(Calendar.SECOND);

            desireddate = year1 + "-" + (month1 + 1) + "-" + day1 + " " + hour1 + ":" + minute1 + ":" + second1;

            Date e = sdf.parse(desireddate);

            desireddate = format.format(e);
        }

        if (kind == 1 && bestseller == 0) {

            Date d = sdf.parse(nowdate);
            DesiredDeliveryDate = RequestDate;

            nowdate = format.format(d);

            DesiredDeliveryDate.add(Calendar.DAY_OF_MONTH, 21);

            int year1 = DesiredDeliveryDate.get(Calendar.YEAR);
            int month1 = DesiredDeliveryDate.get(Calendar.MONTH);
            int day1 = DesiredDeliveryDate.get(Calendar.DAY_OF_MONTH);
            int hour1 = DesiredDeliveryDate.get(Calendar.HOUR);
            int minute1 = DesiredDeliveryDate.get(Calendar.MINUTE);
            int second1 = DesiredDeliveryDate.get(Calendar.SECOND);

            desireddate = year1 + "-" + (month1 + 1) + "-" + day1 + " " + hour1 + ":" + minute1 + ":" + second1;

            Date e = sdf.parse(desireddate);

            desireddate = format.format(e);

        }

        if (kind == 2) {

            Date d = sdf.parse(nowdate);
            DesiredDeliveryDate = RequestDate;

            nowdate = format.format(d);

            DesiredDeliveryDate.add(Calendar.DAY_OF_MONTH, 14);

            int year1 = DesiredDeliveryDate.get(Calendar.YEAR);
            int month1 = DesiredDeliveryDate.get(Calendar.MONTH);
            int day1 = DesiredDeliveryDate.get(Calendar.DAY_OF_MONTH);
            int hour1 = DesiredDeliveryDate.get(Calendar.HOUR);
            int minute1 = DesiredDeliveryDate.get(Calendar.MINUTE);
            int second1 = DesiredDeliveryDate.get(Calendar.SECOND);

            desireddate = year1 + "-" + (month1 + 1) + "-" + day1 + " " + hour1 + ":" + minute1 + ":" + second1;

            Date e = sdf.parse(desireddate);

            desireddate = format.format(e);

        }

        if (kind == 1 || kind == 2) {

            if (age <= 12 && itembyuser != 3 || age > 12) {

                if (kind == 1) {

                    JOptionPane.showMessageDialog(null, "This item has to checkout for: " + this.Insert_request(resourceid, cardnumber, nowdate, desireddate, 0) + "this is a book with reference copy: " + resourceid);

                }

                if (kind == 2) {

                    JOptionPane.showMessageDialog(null, "This item has to checkout for: " + this.Insert_request(0, cardnumber, nowdate, desireddate, resourceid) + "this is a multimedia with reference copy: " + resourceid);

                }

            } else {

                JOptionPane.showMessageDialog(null, "The user is less than 12 years old and has now 3 items requested");

            }

        } else {

            JOptionPane.showMessageDialog(null, "The Library not allow to request Magazine or Reference book");

        }

    }

    public String Insert_request(int bookid, int cardnumber, String requestdate, String desierdate, int multimediaid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int edad = 0;
        String sbookid, smultimediaid;
        
        if (bookid == 0) {
            sbookid = null;
        } else {
            sbookid = String.valueOf(bookid);
        }
        if (multimediaid == 0) {
            smultimediaid = null;
        } else {
            smultimediaid = String.valueOf(multimediaid);
        }

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("spU_InsertRequest ?,?,?,?,?");
            ps.setString(1, sbookid);
            ps.setInt(2, cardnumber);
            ps.setString(3, requestdate);
            ps.setString(4, desierdate);
            ps.setString(5, smultimediaid);

            rs = ps.executeQuery();

            rs.close();
            return desierdate;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {

                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {

                }
            }
        }
    }

    public String[][] consult_requests(int cardnumber) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;

        int iteration = 0, sum = 0, row = 1;

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec sp_listrequest ?");
            //ps.setString(1, filter);               
            ps.setInt(1, cardnumber);

            System.out.println();

            rs = ps.executeQuery();
            while (rs.next()) {
                iteration = iteration + 1;
            }
            String books[][] = new String[iteration][7];
            rs = ps.executeQuery();
            while (rs.next()) {

                //System.out.println(rs.getString(1)+ " , "+ rs.getString(2));
                books[sum][0] = rs.getString(1);
                books[sum][1] = rs.getString(2);
                books[sum][2] = String.valueOf(rs.getDate(3));
                books[sum][3] = rs.getString(4);

                //books[sum][5] = String.valueOf(rs.getDate(6));
                sum = sum + 1;
            }
            System.out.println(books[0][0]);
            rs.close();
            return books;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }

    }

    public int consult_bookid(int requestid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int edad = 0;

        int iteration = 0, sum = 0, row = 1;

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec sp_requestbookid ?");
            ps.setInt(1, requestid);

            rs = ps.executeQuery();
            while (rs.next()) {
                edad = rs.getInt(1);
            }
            rs.close();
            return edad;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {

                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {

                }
            }
        }
    }

    public int consult_multimediaid(int requestid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int edad = 0;

        int iteration = 0, sum = 0, row = 1;

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec sp_requestmultimediaid ?");
            ps.setInt(1, requestid);

            rs = ps.executeQuery();
            while (rs.next()) {
                edad = rs.getInt(1);
            }
            rs.close();
            return edad;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {

                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {

                }
            }
        }
    }
    
    
     public int consult_kindbyrequestid(int requestid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int edad = 0;

        int iteration = 0, sum = 0, row = 1;

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec sp_kindbyrequestid ?");
            ps.setInt(1, requestid);

            rs = ps.executeQuery();
            while (rs.next()) {
                edad = rs.getInt(1);
            }
            rs.close();
            return edad;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {

                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {

                }
            }
        }
    }
     
      public String Insert_renew(int bookid, int cardnumber, String requestdate, String desierdate, int multimediaid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int edad = 0;
        String sbookid, smultimediaid;
        
        if (bookid == 0) {
            sbookid = null;
        } else {
            sbookid = String.valueOf(bookid);
        }
        if (multimediaid == 0) {
            smultimediaid = null;
        } else {
            smultimediaid = String.valueOf(multimediaid);
        }

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("spU_InsertRequest ?,?,?,?,?");
            ps.setString(1, sbookid);
            ps.setInt(2, cardnumber);
            ps.setString(3, requestdate);
            ps.setString(4, desierdate);
            ps.setString(5, smultimediaid);

            rs = ps.executeQuery();

            rs.close();
            return desierdate;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {

                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {

                }
            }
        }
    }


}
