/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Daniel
 */
public class Item {

    public Integer ID;
    public String Name;
    public String Genre;
    public String Kind;
    public String Autor;
    public Date Publicationdate;
    public Integer price;

    public void ItemRequest(int Kind) {

    }

    public String[][] consult_books(String filter, String kind) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;

        int iteration = 0, sum = 0, row = 1;

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec sp_listbook ?,?");
            //ps.setString(1, filter);               
            ps.setString(1, filter);
            ps.setString(2, kind);

            System.out.println();

            rs = ps.executeQuery();
            while (rs.next()) {
                iteration = iteration + 1;
            }
            String books[][] = new String[iteration][7];
            rs = ps.executeQuery();
            while (rs.next()) {

                //System.out.println(rs.getString(1)+ " , "+ rs.getString(2));
                books[sum][0] = rs.getString(1);
                books[sum][1] = rs.getString(2);
                books[sum][2] = rs.getString(3);
                books[sum][3] = rs.getString(4);
                books[sum][4] = rs.getString(5);
                books[sum][5] = String.valueOf(rs.getDate(6));
                books[sum][6] = rs.getString(7);

                //books[sum][5] = String.valueOf(rs.getDate(6));
                sum = sum + 1;
            }
            System.out.println(books[0]);
            rs.close();
            return books;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }

    }

    public int consult_kind(int itemid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int kind = 0;

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec spU_itemid ?");
            //ps.setString(1, filter);   

            ps.setInt(1, itemid);

            System.out.println();

            rs = ps.executeQuery();
            while (rs.next()) {
                kind = rs.getInt(1);
            }
            rs.close();
            return kind;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }

    }

    public int consult_itembyuser(int cardnumber) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int item = 0;

        int iteration = 0, sum = 0, row = 1;

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec spU_itembyuser ?");
            ps.setInt(1, cardnumber);

            rs = ps.executeQuery();
            while (rs.next()) {
                item = rs.getInt(1);
            }
            rs.close();
            return item;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {

                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {

                }
            }
        }
    }

}
