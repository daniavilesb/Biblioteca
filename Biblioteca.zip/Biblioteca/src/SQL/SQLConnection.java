/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SQL;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Daniel
 */
public class SQLConnection {

    public Connection Connection() throws IOException {
        String connectionUrl = "jdbc:sqlserver://localhost\\SQLEXPRESS:5081;databaseName=Library;integratedSecurity=false;user=Usrlibrary;password=Chambones123";
        Connection con = null;

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(connectionUrl);
            
            System.out.println ("Conexion exitosa");
            
            
            return (con);
        } catch (SQLException | ClassNotFoundException ex) {

            System.out.println(ex);
            
            
            return (con);
        }

    }
}
